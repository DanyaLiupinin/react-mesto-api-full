const Status = {
  OK: 200,
  CREATED: 201,
};

module.exports = Status;
